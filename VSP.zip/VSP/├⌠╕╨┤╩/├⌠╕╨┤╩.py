﻿words=('wdnmd','我带你们打','wc','暴力')
text ='我喜欢你'
for word in words:
    if word in text:
        tex=text
print(text)
