﻿x_list = [1,2,3]
x_tuple = (1,2,3)
x_dict = {'a':97,'b':98,'c':99}
x_set ={1,2,3}
print(x_list[1],x_tuple[2],x_dict['a'])

print(3+5<<1)
print(3+(5<<1))
print(789%23)
print(3**2)
print(3**2**3)
print({1,2,3}=={3,2,1})
print(3 in [1,2,3])
print(5 in range(10,1,-1))
print({1,2,3}|{3,4,5})

i=3
print(i++i)
print(3 not in [1,2,3])
print(3>5 or 5>3)

